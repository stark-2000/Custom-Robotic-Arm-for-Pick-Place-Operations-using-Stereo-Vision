class constants:
    EASING_FUNCTION_TYPE = {"SIN":0, "QAD":1, "LIN":2, "EXP":3, "ELA":4, "CIR":5, "BOU":6, "BAK":7, "TRI":8, "TRW":9, "SNW":10, "SPR":11}
    EASING_CURVE_TYPE = {"IN":0, "OU":1, "IO":2}