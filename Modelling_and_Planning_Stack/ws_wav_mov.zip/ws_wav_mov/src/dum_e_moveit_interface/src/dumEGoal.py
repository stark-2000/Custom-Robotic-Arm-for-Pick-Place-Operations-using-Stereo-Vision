import sys
import math
import rospy
import moveit_commander

from geometry_msgs.msg import Pose
from moveit_msgs.msg import CollisionObject
from shape_msgs.msg import SolidPrimitive

from tf.transformations import quaternion_from_euler
import time

# FRAME_ID = 'world'
# (X, Y, Z, W) = (0, 1, 2, 3)
# OPEN = 0.9
# CLOSE = 0.15
# OBJECT_POSITIONS = {'target_1': [0, -0.4, 0.30]}
# PICK_ORIENTATION_EULER = [0, 0, -math.pi / 2]
# PLACE_ORIENTATION_EULER = [-math.pi / 2, 0, -math.pi / 2]
# SCENE = moveit_commander.PlanningSceneInterface()


# def move_to_goal(arm):
#     pose = Pose()
#     pose.position.x = 0
#     pose.position.y = -0.2
#     pose.position.z = 0.2
#     pose.orientation.w = 1.0
#     arm.set_pose_target(pose)
#     arm.set_goal_position_tolerance(0.001)
#     return arm.go(wait=True)

# def create_collision_object(id, dimensions, pose):
#     object = CollisionObject()
#     object.id = id
#     object.header.frame_id = FRAME_ID

#     solid = SolidPrimitive()
#     solid.type = solid.BOX
#     solid.dimensions = dimensions
#     object.primitives = [solid]

#     object_pose = Pose()
#     object_pose.position.x = pose[X]
#     object_pose.position.y = pose[Y]
#     object_pose.position.z = pose[Z]

#     object.primitive_poses = [object_pose]
#     object.operation = object.ADD
#     return object

# def add_collision_objects():
#     target_1 = create_collision_object(id='target_1',
#                                        dimensions=[0.02, 0.02, 0.2],
#                                        pose=[0, -0.4, 0.30])  #y,z,x

#     SCENE.add_object(target_1)



class dumEGoal:
    def __init__(self) -> None:   
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('dum_e_pick_place')
        rospy.sleep(2)

        self.arm = moveit_commander.MoveGroupCommander('dum_e_group',
                                                ns=rospy.get_namespace())

        self.arm.set_num_planning_attempts(1000)

    def go_left(self):
        self.arm.set_named_target("left_pose")
        self.arm.go(wait=True)

    def go_centre(self):
        self.arm.set_named_target("centre_pose")
        self.arm.go(wait=True)


    def go_right(self):
        self.arm.set_named_target("right_pose")
        self.arm.go(wait=True)


    def go_stand(self):
        self.arm.set_named_target("stand")
        self.arm.go(wait=True)


if __name__ == '__main__':
    _dumEGoal = dumEGoal()
    _dumEGoal.go_left()
    time.sleep(5)
    _dumEGoal.go_centre()
    time.sleep(5)
    _dumEGoal.go_right()
    time.sleep(5)
    _dumEGoal.go_stand()
    time.sleep(5)