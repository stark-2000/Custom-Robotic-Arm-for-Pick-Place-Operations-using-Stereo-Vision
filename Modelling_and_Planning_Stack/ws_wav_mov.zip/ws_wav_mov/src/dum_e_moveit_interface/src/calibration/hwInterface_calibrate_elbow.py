import serial
import time
import threading

from constants import *
from addressMap import *
from commandBuilder import *

class hwInterface:

    def __init__(self) -> None:
        self.MONITOR_ACTUATOR = False
        self.tMonitor = threading.Thread(target=self.read_angles)

    #region Port related functions--------------------------------------
    def initialize(self):

        self.set_actuator_timing("ELBOW", 100)
        self.set_actuator_angle("ELBOW", 150)
        self.trigger()
        time.sleep(1)

        print("ELBOW PWM ON")
        cmd = commandBuilder.build_command_frame("ELBOW", "PWM_ON")
        self.sendCommand(cmd)
        print("ELBOW PWR ON")
        cmd = commandBuilder.build_command_frame("ELBOW", "PWR_ON")
        self.sendCommand(cmd)


    def open(self):
        self.port = serial.Serial(port='/dev/ttyUSB7',baudrate=115200 )
        #Controller warm-up delay
        time.sleep(1.5)
        self.initialize()

    def close(self):
        self.port.close()

    def readData(self, cmd, len):
        bytes = serial.to_bytes(cmd)
        self.port.write(bytes)
        statusBytes = self.port.read(len)
        return int.from_bytes(statusBytes, 'little')
    
    def sendCommand(self, cmd):
        bytes = serial.to_bytes(cmd)
        self.port.write(bytes)
        return int.from_bytes(self.port.read(1), 'big')
    #endregion ---------------------------------------------------------------------------------------------
    
    #region actuator monitor--------------------------------------------
    def read_angles(self):
        while self.MONITOR_ACTUATOR:
            ELBOW = self.read_actuator_angle("ELBOW")
            print(f"{ELBOW}")
            time.sleep(0.5)
 

    def begin_actuator_monitor(self):
        self.MONITOR_ACTUATOR = True
        self.tMonitor = threading.Thread(target=self.read_angles)
        self.tMonitor.start()

    def stop_actuator_monitor(self):
        self.MONITOR_ACTUATOR = False
        self.tMonitor.join()

    #endregion----------------------------------------------------------

    #region actuator command interface --------------------------------------------
    def _map(self, x, in_min, in_max, out_min, out_max):
        return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)
	
    def read_actuator_angle(self, actuator):
        cmd = commandBuilder.build_status_frame(actuator, "ANGLE")
        pwm = self.readData(cmd, addressMap.ACTUATOR_STATUS_REG_LEN["ANGLE"])
        degree = self._map(pwm, 500, 2500, 0, 270)
        return degree
        
    def set_actuator_timing(self, actuator, timing):
        data = [timing&0xFF, timing>>8&0xFF]
        cmd = commandBuilder.build_data_frame(actuator, "TIMING", data)
        self.sendCommand(cmd)

    def set_actuator_easing_func(self, actuator, func):
        data = [func]
        cmd = commandBuilder.build_data_frame(actuator, "EAS_FUNC", data)
        self.sendCommand(cmd)

    def set_actuator_easing_typ(self, actuator, typ):
        data = [typ]
        cmd = commandBuilder.build_data_frame(actuator, "EAS_TYP", data)
        self.sendCommand(cmd)

    def set_actuator_angle(self, actuator, angle):
        PWM = self._map(angle, 0, 270, 500, 2500)
        data = [PWM&0xFF, PWM>>8&0xFF]
        cmd = commandBuilder.build_data_frame(actuator, "ANGLE", data)
        self.sendCommand(cmd)

    def trigger(self):
        cmd = commandBuilder.build_command_frame("BUS", "TRG")
        bytes = serial.to_bytes(cmd)
        self.sendCommand(cmd)
    #endregion




if __name__ == "__main__":

    try:
        _hwInterface = hwInterface()

        _hwInterface.open()
        # _hwInterface.begin_actuator_monitor()

        
        # _hwInterface.stop_actuator_monitor()

        _hwInterface.set_actuator_easing_func("ELBOW", constants.EASING_FUNCTION_TYPE["LIN"])
        _hwInterface.set_actuator_easing_typ("ELBOW", constants.EASING_CURVE_TYPE["IO"])

        _hwInterface.set_actuator_timing("ELBOW", 5000)
        #ELBOW measured range : #0/60  - 90/150 - 180/240
        #ELBOW measured range : #90/60 - 0/150  - -90/240
        _hwInterface.set_actuator_angle("ELBOW", 150)
        _hwInterface.trigger()

        # _hwInterface.begin_actuator_monitor()

        while True:
            time.sleep(1)

    except Exception as e:
        print(e)
    finally:
        _hwInterface.stop_actuator_monitor()
        _hwInterface.close()

