import tkinter as tk
from tkinter import ttk

from hwInterface import *


# root window
root = tk.Tk()
root.tk.call('tk', 'scaling', 1000.0)

root.geometry('800x600')
root.resizable(True, True)
root.title('Manipulator Control')


root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=3)


_hwInterface = hwInterface()

_hwInterface.open()

_hwInterface.set_actuator_timing("TURN", 100)
_hwInterface.set_actuator_timing("LIFT", 100)
_hwInterface.set_actuator_timing("TWIST", 100)
_hwInterface.set_actuator_timing("ELBOW", 100)
_hwInterface.set_actuator_easing_func("TURN", constants.EASING_FUNCTION_TYPE["LIN"])
_hwInterface.set_actuator_easing_typ("TURN", constants.EASING_CURVE_TYPE["IO"])
_hwInterface.set_actuator_easing_func("LIFT", constants.EASING_FUNCTION_TYPE["LIN"])
_hwInterface.set_actuator_easing_typ("LIFT", constants.EASING_CURVE_TYPE["IO"])
_hwInterface.set_actuator_easing_func("TWIST", constants.EASING_FUNCTION_TYPE["LIN"])
_hwInterface.set_actuator_easing_typ("TWIST", constants.EASING_CURVE_TYPE["IO"])
_hwInterface.set_actuator_easing_func("ELBOW", constants.EASING_FUNCTION_TYPE["LIN"])
_hwInterface.set_actuator_easing_typ("ELBOW", constants.EASING_CURVE_TYPE["IO"])

_hwInterface.begin_actuator_monitor()



class sliderControl:

    def __init__(self) -> None:
        self.current_value = tk.DoubleVar()
        self.int_value = 0
        self.prev_int_value = 0


    def get_current_value(self):
        self.int_value = int(self.current_value.get())
        return f'{self.int_value}'


    def slider_changed(self,event):
        self.slider_label.configure(text=f"{self.text} : {self.get_current_value()}")
        if self.prev_int_value != self.int_value:
            print(f"Move {self.text} to : {self.int_value}")

            _hwInterface.stop_actuator_monitor()
            
            _hwInterface.set_actuator_angle(self.text,  self.int_value)
            _hwInterface.trigger()

            _hwInterface.begin_actuator_monitor()

            self.prev_int_value = self.int_value

    def make_slider(self, _root, row, label):


        self.text = label
        # label for the slider
        self.slider_label = ttk.Label(
            _root,
            text=f"{self.text} : {self.get_current_value()}"
        )

        self.slider_label.grid(
            column=0,
            row=row,
            sticky='w'
        )

        #  slider
        self.slider = ttk.Scale(
            _root,
            from_=0,
            to=270,
            orient='horizontal',  # vertical
            command=self.slider_changed,
            variable=self.current_value
        )

        self.slider.grid(
            column=1,
            row=row,
            sticky='we'
        )


try:



    turnSlider = sliderControl();   turnSlider.make_slider(root, 0, "TURN")
    liftSlider = sliderControl();   liftSlider.make_slider(root, 1, "LIFT")
    twistSlider = sliderControl();   twistSlider.make_slider(root, 2, "TWIST")
    elbowSlider = sliderControl();   elbowSlider.make_slider(root, 3, "ELBOW")
        
    root.mainloop()


except Exception as e:
    print(e)
finally:
    _hwInterface.stop_actuator_monitor()
    _hwInterface.close()
