import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list


import numpy as np


class moveitInterface:

    def __init__(self, motionPlanCallback):
        self.motionPlanCallback = motionPlanCallback

    def trjectoryCallback(self, data):
        positions = []

        if data is not None and len(data.trajectory) > 0:
            robotTrajectory = data.trajectory[0]
            jointTrajectory = robotTrajectory.joint_trajectory
            trajectoryPoints = jointTrajectory.points

            if trajectoryPoints is not None and len(trajectoryPoints) > 0:
                #get all trajectory points
                for trajectoryPoint in trajectoryPoints:
                    positions.append(trajectoryPoint.positions)
                
                #convert to positive angles i.e., -90-90 to 0-180
                positions = np.array(positions)
                #convert to degrees
                positions = positions*180/3.14
                #convert to integers
                positions = positions.astype(np.int16)

                if self.motionPlanCallback is not None:
                    self.motionPlanCallback(positions)
                
        
    def subscribe_to_trajectory(self):
        rospy.init_node('dum_e_moveit_interface')
        rospy.Subscriber("/move_group/display_planned_path", moveit_msgs.msg.DisplayTrajectory, self.trjectoryCallback)
        print("planner is ready.")
        rospy.spin()



if __name__ == "__main__":
    def motionPlanCallback(postions):
        print(f"Recieved positons : {postions}")
        
    _moveitInterface = moveitInterface(motionPlanCallback)
    _moveitInterface.subscribe_to_trajectory()