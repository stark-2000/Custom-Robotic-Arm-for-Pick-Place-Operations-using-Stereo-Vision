


class addressMap:

    ACTUATOR_ADDRESS = {
        "TURN":0x06, "LIFT":0x07, "TWIST":0x09, "ELBOW":0x08, "BUS":0x00
    }


    ACTUATOR_STATUS_REG_BASE_ADR  = 0x10
    ACTUATOR_STATUS_REG_ADR = {
        "PWR":0, "PWM":1, "MOTION":2, "ANGLE":3
    }
    ACTUATOR_STATUS_REG_LEN = {
        "PWR":1, "PWM":1, "MOTION":1, "ANGLE":2
    }

    ACTUATOR_DATA_REG_BASE_ADR    = 0x30
    ACTUATOR_DATA_REG_ADR = {
        "ANGLE":0, "TIMING":2, "DELAY":4, "FREQUENCY":6, "DAMPING":8,
        "VELOCITY":10, "EAS_FUNC":12, "EAS_TYP":13
    }
    ACTUATOR_DATA_REG_LEN = {
        "ANGLE":2, "TIMING":2, "DELAY":2, "FREQUENCY":2, "DAMPING":2,
        "VELOCITY":2, "EAS_FUNC":1, "EAS_TYP":1
    }

    ACTUATOR_COMMAND_REG_BASE_ADR = 0x90
    ACTUATOR_COMMAND_REG_ADR = {
        "PWM_ON":0, "PWM_OFF":1, "PWR_ON":2, "PWR_OFF":3,
        "TRG":4, "CALIB":5
    }
    ACTUATOR_COMMAND_REG_LEN = {
        "PWM_ON":1, "PWM_OFF":1, "PWR_ON":1, "PWR_OFF":1,
        "TRG":1, "CALIB":1
    }
