import time

from hwInterface import *
from moveitInterface import *



class dumEMove:

    def __init__(self):

        self.TURN_ZERO = 126
        self.LIFT_ZERO = 136
        self.TWIST_ZERO = 126
        self.ELBOW_ZERO = 150

        self._hwInterface = hwInterface()

        self._hwInterface.open()

        self._hwInterface.set_actuator_timing("TURN", 200)
        self._hwInterface.set_actuator_timing("LIFT", 200)
        self._hwInterface.set_actuator_timing("TWIST", 200)
        self._hwInterface.set_actuator_timing("ELBOW", 200)
        self._hwInterface.set_actuator_easing_func("TURN", constants.EASING_FUNCTION_TYPE["LIN"])
        self._hwInterface.set_actuator_easing_typ("TURN", constants.EASING_CURVE_TYPE["IO"])
        self._hwInterface.set_actuator_easing_func("LIFT", constants.EASING_FUNCTION_TYPE["LIN"])
        self._hwInterface.set_actuator_easing_typ("LIFT", constants.EASING_CURVE_TYPE["IO"])
        self._hwInterface.set_actuator_easing_func("TWIST", constants.EASING_FUNCTION_TYPE["LIN"])
        self._hwInterface.set_actuator_easing_typ("TWIST", constants.EASING_CURVE_TYPE["IO"])
        self._hwInterface.set_actuator_easing_func("ELBOW", constants.EASING_FUNCTION_TYPE["LIN"])
        self._hwInterface.set_actuator_easing_typ("ELBOW", constants.EASING_CURVE_TYPE["IO"])

        # self._hwInterface.begin_actuator_monitor()

        time.sleep(5)
        self._moveitInterface = moveitInterface(self.motionPlanCallback)
        self._moveitInterface.subscribe_to_trajectory()


    def motionPlanCallback(self, positions):
        print(f"dumEMove::motionPlanCallback : {positions}")
        for position in positions:
            print(f"moving to postion {self.TURN_ZERO+position[0]},  {self.LIFT_ZERO+position[1]}, {self.TWIST_ZERO+(position[2])}, {self.ELBOW_ZERO+position[3]}")
            self._hwInterface.set_actuator_angle("TURN", self.TURN_ZERO+position[0])
            self._hwInterface.set_actuator_angle("LIFT", self.LIFT_ZERO+position[1])
            self._hwInterface.set_actuator_angle("TWIST", self.TWIST_ZERO+(position[2]))
            self._hwInterface.set_actuator_angle("ELBOW", self.ELBOW_ZERO+position[3])
            self._hwInterface.trigger()
            time.sleep(0.2)



if __name__ == "__main__":
    _dumEMove = dumEMove()
