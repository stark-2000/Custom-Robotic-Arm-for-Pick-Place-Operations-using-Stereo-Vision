from addressMap import *

class   commandBuilder:
    
    #region controller frame builders-----------------------------------------------------------------------
    def build_command_frame(actuator, command):
        frame = [
            0x02,
            addressMap.ACTUATOR_ADDRESS[actuator],
            addressMap.ACTUATOR_COMMAND_REG_BASE_ADR+addressMap.ACTUATOR_COMMAND_REG_ADR[command],
            addressMap.ACTUATOR_COMMAND_REG_LEN[command]
        ]

        return frame
    

    def build_data_frame(actuator, parameter, data):
        frame = [
            0x02+len(data),
            addressMap.ACTUATOR_ADDRESS[actuator],
            addressMap.ACTUATOR_DATA_REG_BASE_ADR+addressMap.ACTUATOR_DATA_REG_ADR[parameter],
            addressMap.ACTUATOR_DATA_REG_LEN[parameter]
        ]+data

        return frame
    
    def build_status_frame(actuator, flag):
        frame = [
            0x02,
            addressMap.ACTUATOR_ADDRESS[actuator] | 0x80,
            addressMap.ACTUATOR_STATUS_REG_BASE_ADR+addressMap.ACTUATOR_STATUS_REG_ADR[flag],
            addressMap.ACTUATOR_STATUS_REG_LEN[flag]
        ]

        return frame
    #endregion -----------------------------------------------------------------------------------------------
